//
//  ViewController.h
//  animation in ios
//
//  Created by MACOS on 01/10/16.
//  Copyright © 2016 aarti. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)btn_click:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *view1;


@end

