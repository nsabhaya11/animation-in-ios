//
//  ViewController.m
//  animation in ios
//
//  Created by MACOS on 01/10/16.
//  Copyright © 2016 aarti. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btn_click:(id)sender {
    
   // float h1=_view1.frame.size.height;
   // float w1=_view1.frame.size.width;

   // _view1.frame=CGRectMake(_view1.frame.origin.x, _view1.frame.origin.y, 0, 0);
    _view1.alpha=0;
    
    [UIView animateWithDuration:2 animations:^{
        
    // _view1.frame=CGRectMake(_view1.frame.origin.x, _view1.frame.origin.y, w1, h1);
        
        _view1.alpha=1;
        
    }];
    
    
    
    

    
}

@end
